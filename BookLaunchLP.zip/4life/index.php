<!DOCTYPE html>
<html lang="en">

<head>
    <script>
        (function (w, d, s, l, i) {
            w[l] = w[l] || [];
            w[l].push({
                'gtm.start': new Date().getTime(),
                event: 'gtm.js'
            });
            var f = d.getElementsByTagName(s)[0],
                j = d.createElement(s),
                dl = l != 'dataLayer' ? '&l=' + l : '';
            j.async = true;
            j.src =
                'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
            f.parentNode.insertBefore(j, f);
        })(window, document, 'script', 'dataLayer', 'GTM-PRKB4P8D');
    </script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>4 Life</title>
    <!-- bootstrap css cdn -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" />
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp" rel="stylesheet">
    <!-- Bootstrap Datepicker CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css"
        rel="stylesheet">
    <link rel="stylesheet" href="css/index.css">
</head>

<body class="loading">

    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-PRKB4P8D" height="0" width="0"
            style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->


    <div class="loader-wrapper">
        <div class="loader-container">
            <div class="loader"></div>
        </div>
    </div>

    <main>


        <div class="toggle-up-content">
            <div class="toggle-up">
                <i class="fa-solid fa-chevron-up"></i>
            </div>

        </div>

        <!-- offcanvas -->
        <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasExample"
            aria-labelledby="offcanvasExampleLabel">
            <div class="offcanvas-header">
                <!-- <h5 class="offcanvas-title" id="offcanvasExampleLabel">Offcanvas</h5> -->
                <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
            </div>
            <div class="offcanvas-body">
                <div class="navigation-links">
                    <div class="links">
                        <a href="#seeProof" class="navItems">See the Proof</a>
                        <div class="line"></div>
                        <a href="#howWork" class="navItems">How It Works</a>
                        <div class="line"></div>
                        <a href="#joinUs" class="navItems">Join Us</a>
                        <div class="line"></div>
                        <a href="#downloadBook" class="navItems">Download Free E-Book Now!</a>
                    </div>
                </div>
            </div>
        </div>
        <!-- offcanvas -->



        <!-- step modal -->

        <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
            aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
                <div class="modal-content">
                    <div class="modal-body stepper-modal">
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        <div class="steps-container">
                            <div class="steps-content">

                                <div class="steps-header">
                                    Book your Zoom call, and start
                                    your transformation!
                                </div>

                                <!-- <div class="progress-container">
                                    <div class="progress-box" id="progress"></div>
                                    <div id="firstCircle" class="circle active">
                                        <span></span>
                                        <strong class="circle-title">Step 1</strong>
                                    </div>

                                    <div id="secondCircle" class="circle">
                                        <span></span>
                                        <strong class="circle-title">Step 2</strong>
                                    </div>

                                    <div id="thridCircle" class="circle">
                                        <span></span>
                                        <strong class="circle-title">Step 3</strong>
                                    </div>
                                </div> -->

                                <div class="steps-inputs">
                                    <form action="thankyou.php" method="POST" class="needs-validation" novalidate>
                                        <div class="row g-4">
                                            <div class="col-xl-12 col-lg-12 col-md-12">
                                                <div class="input">
                                                    <label class="input-title">Full Name</label>
                                                    <input type="text" placeholder="Your Name" class="form-control"
                                                        name="fname" id="txtFullName3" required>
                                                    <div class="invalid-feedback">
                                                        Please enter valid name
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-xl-12 col-lg-12 col-md-12">
                                                <div class="input">
                                                    <label class="input-title">Email Id</label>
                                                    <input type="email" placeholder="yourname@example.com" name="email"
                                                        class="form-control" required id="txtEmail3">
                                                    <div class="invalid-feedback">
                                                        Please enter valid email.
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-xl-12 col-lg-12 col-md-12">
                                                <div class="input">
                                                    <label class="input-title">Mobile No.</label>
                                                    <span class="country-code">+91 | </span>
                                                    <input type="text" class="mobile form-control number-only"
                                                        name="mobile" maxlength="10" id="txtMobile3" required
                                                        placeholder="Enter your mobile no.">
                                                    <div class="invalid-feedback mobile-validate-3">
                                                        Please enter 10 digit mobile number
                                                    </div>
                                                </div>
                                            </div>


                                            <div class="col-xl-12 col-lg-12 col-md-12">
                                                <div class="input">
                                                    <label class="input-title">State</label>
                                                    <select class="form-select state-select"
                                                        aria-label="Default select example" name="state"
                                                        class="form-control" required id="txtState3">
                                                        <option selected hidden value="">Select</option>
                                                    </select>
                                                    <div class="invalid-feedback">
                                                        Please choose state
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-xl-12 col-lg-12 col-md-12">
                                                <div class="input">
                                                    <label class="input-title">Message</label>
                                                    <textarea name="message" placeholder="Type message..."
                                                        class="form-control" required id="txtMessage3"></textarea>
                                                    <div class="invalid-feedback">
                                                        Please enter valid message
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-xl-12 col-lg-12 col-md-12">
                                                <div class="input-submit">
                                                    <button class="btn-sumbit" id="btnModalSubmit">
                                                        <span class="text-uppercase btn-sumbit-txt">
                                                            SUBMIT</span>
                                                        <span class="btn-sumbit-img"><img src="assets/icons/Arrow.png"
                                                                alt="arrows"></span>
                                                    </button>
                                                </div>
                                            </div>

                                            <!-- <div class="col-xl-12 col-lg-12 col-md-12 mx-auto">
                                                <div id="datepicker" class="datepicker"></div>
                                            </div>

                                            <div class="col-xl-12 col-lg-12 col-md-12">
                                                <input type="text" id="selectDate">
                                            </div> -->

                                        </div>
                                    </form>

                                </div>


                            </div>

                        </div>

                    </div>
                </div>
            </div>
        </div>
        <!-- step modal -->

        <div class="floating-btn">
            <button class="btn-float" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                <span class="btn-icon">
                    <img src="assets/icons/msg.png" alt="message">
                </span>
                <span class="btn-txt">Join and transform today!</span></button>
        </div>

        <section id="downloadBook">
            <div class="main-container">
                <div class="banner-head">
                    <div class="navbar-container">
                        <div class="navbar-links">

                            <div class="link-items">
                                <a href="#seeProof" class="navItem">See the Proof</a>
                            </div>

                            <div class="link-items">
                                <a href="#howWork" class="navItem">How It Works</a>
                            </div>

                            <div class="link-items">
                                <a href="#joinUs" class="navItem">Join Us</a>
                            </div>

                            <div class="link-items">
                                <a href="#downloadBook" class="navItem active">Download Free E-Book Now!</a>
                            </div>


                        </div>

                        <div class="navbar-menu" data-bs-toggle="offcanvas" href="#offcanvasExample" role="button"
                            aria-controls="offcanvasExample">
                            <div class="navbar-icon">
                                <img src="assets/icons/menu.png" alt="menu">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="main-banner">

                    <div class="d-none d-md-block">
                        <img src="assets/banner/banner.jpg" class="loading" alt="Image 1">
                    </div>

                    <div class="d-block d-md-none">
                        <img class="mobimage" src="assets/banner/mobile-banner.jpg" class="loading" alt="Image 1">
                    </div>



                    <!-- <img src="assets/banner/banner.jpg" alt="banner"> -->
                </div>


                <div class="banner-input">
                    <form action="thankyou.php" id="formEbook" method="POST" class="needs-validation" novalidate>
                        <div class="input-container">
                            <div class="input-content">
                                <div class="step-head">Step 1 - <span class="primary">Schedule your appointment</span>
                                </div>
                                <div class="input-details">
                                    <div class="inputs">
                                        <div class="input">
                                            <label class="input-title">Full Name</label>
                                            <input type="text" class="form-control" id="txtFullName" name="fname"
                                                placeholder="Your Name" required>
                                            <div class="invalid-feedback">
                                                Please enter valid name
                                            </div>
                                        </div>

                                        <div class="input">
                                            <label class="input-title">Email Id</label>
                                            <input type="email" id="txtEmail" class="form-control" name="email"
                                                placeholder="yourname@example.com" required>
                                            <div class="invalid-feedback">
                                                Please enter valid email.
                                            </div>
                                        </div>

                                        <div class="input">
                                            <label class="input-title">Mobile No.</label>
                                            <span class="country-code">+91 | </span>
                                            <input type="text" class="form-control mobile number-only" id="txtMobile"
                                                name="mobile" placeholder="Enter your mobile no." maxlength="10"
                                                required>
                                            <div class="invalid-feedback mobile-validate">
                                                Please enter 10 digit mobile number
                                            </div>
                                        </div>

                                        <div class="input">
                                            <label class="input-title">State</label>
                                            <select class="form-select state-select" aria-label="Default select example"
                                                name="state" id="txtState" required>
                                                <option selected hidden value="">Select</option>
                                            </select>
                                            <div class="invalid-feedback">
                                                Please choose state
                                            </div>
                                        </div>
                                    </div>

                                    <div class="input-msg">
                                        <label class="input-title">message</label>
                                        <textarea class="form-control" placeholder="Type message..." name="message"
                                            id="txtMessage" required></textarea>
                                        <div class="invalid-feedback">
                                            Please enter valid message
                                        </div>
                                    </div>
                                </div>

                            </div>


                            <!-- data-bs-toggle="modal" data-bs-target="#staticBackdrop" -->

                            <div class="input-submit">
                                <button class="btn-sumbit" type="submit" id="btnEbook">
                                    <span class="text-uppercase btn-sumbit-txt">Get free E-Book</span>
                                    <span class="btn-sumbit-img"><img src="assets/icons/Arrow.png" alt="arrows"></span>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>

            </div>
        </section>

        <section class="second-banner">
            <div class="second-container">
                <div class="row gy-5 gx-3">
                    <div class="col-xl-12 col-lg-12 col-md-12">
                        <div class="video-container">
                            <img src="assets/image/video.png" class="img-fluid mx-auto d-block" alt="video">
                            <div class="play-icon">
                                <img src="assets/icons/play.svg" alt="play">
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-12 col-lg-12 col-md-12">
                        <div class="second-banner-txt">
                            <p class="para1">Learn from</p>
                            <span class="amazon"><img src="assets/icons/amazon-pay.png" alt="amazon"></span> <span
                                class="amazon"><img src="assets/icons/amazon-best-seller.png" alt="amazon"></span>
                            <p>the author
                                who has
                                <span class="primary">Transformed 1000+ Lives </span>
                            </p>
                            <p class="ms-2"> and helped them reach their peak.</p>
                        </div>
                    </div>

                    <div class="col-xl-12 col-lg-12 col-md-12 text-center">
                        <button class="btn-journey" data-bs-toggle="modal" data-bs-target="#staticBackdrop">Begin your
                            journey today!</button>
                    </div>

                </div>

            </div>
        </section>

        <section id="seeProof">
            <div class="section-proof">
                <div class="container">
                    <div class="row g-4">
                        <div class="col-xl-12 col-lg-12 col-md-12">
                            <h3 class="proof-title text-center">See the Proof</h3>
                        </div>
                        <div class="col-xl-12 col-lg-12 col-md-12">
                            <p class="proof-subtitle text-center">Through <strong>Jeff's guidance,</strong> many have
                                found success. We
                                <br>
                                want you to reach
                                your highest
                                potential as well.
                            </p>
                        </div>
                    </div>

                    <div class="proof-boxes">
                        <div class="row g-3 justify-content-center align-items-center">
                            <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12">
                                <div class="proof-box">
                                    <div class="proof-img">
                                        <img src="assets/image/box1.jpg" class="img-fluid" alt="customer">
                                    </div>

                                    <div class="proof-txt">
                                        <p class="text-center">Sheri Din</p>
                                    </div>

                                </div>
                            </div>

                            <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12">
                                <div class="proof-box">
                                    <div class="proof-img">
                                        <img src="assets/image/box2.jpg" class="img-fluid" alt="customer">
                                    </div>

                                    <div class="proof-txt">
                                        <p class="text-center">Sadik Din</p>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12">
                                <div class="proof-box">
                                    <div class="proof-img">
                                        <img src="assets/image/box3.jpg" class="img-fluid" alt="customer">
                                    </div>

                                    <div class="proof-txt">
                                        <p class="text-center">Linda Emerson</p>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-12 col-lg-12 col-md-12 text-center">
                                <button class="btn-today" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                                    Start changing your life today!
                                </button>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </section>


        <section id="howWork">
            <div class="how-its-work">
                <div class="container">
                    <div class="how-its-work-container">
                        <div class="how-its-work-content">
                            <div class="work-title">
                                <h3 class="text-center">How It Works</h3>
                            </div>

                            <div class="row">
                                <!-- type 1 -->
                                <div class="col-xl-12 col-lg-12 col-md-12">
                                    <div class="work-types">
                                        <div class="row justify-content-center align-items-center reserve">
                                            <div class="col-xl-6 col-lg-6 col-md-12">
                                                <div class="work-type">
                                                    <div class="work-type-img">
                                                        <img src="assets/image/lap.png" alt="laptop"
                                                            class="lap-img img-fluid">
                                                        <div class="work-arrow">
                                                            <img src="assets/icons/arrow.svg" alt="arrow">
                                                            <button class="btn-book" data-bs-toggle="modal"
                                                                data-bs-target="#staticBackdrop">Download The
                                                                Book</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-xl-6 col-lg-6 col-md-12 reserve">
                                                <div class="work-type-txt">
                                                    <div class="type-no">
                                                        <h5>01</h5>
                                                    </div>

                                                    <h3 class="work-type-txt-title">Download The Ebook</h3>
                                                    <p class="work-type-txt-subtitle">Click the link below to get your
                                                        free copy of "Reaching the
                                                        Peak."
                                                    </p>

                                                    <div class="steps">
                                                        <button class="btn-step" data-bs-toggle="modal"
                                                            data-bs-target="#staticBackdrop">Take the first step
                                                            now!</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- type 2 -->
                                <div class="col-xl-12 col-lg-12 col-md-12 mt-5">
                                    <div class="work-types">
                                        <div class="row justify-content-center align-items-center no-reserve">
                                            <div class="col-xl-6 col-lg-6 col-md-12">
                                                <div class="work-type-txt">
                                                    <div class="type-no type-no-2">
                                                        <h5>02</h5>
                                                    </div>

                                                    <h3 class="work-type-txt-title">Book Your Slot</h3>
                                                    <p class="work-type-txt-subtitle">After downloading the ebook,
                                                        you'll be redirected to a booking page to schedule your personal
                                                        Zoom call with Jeff have a
                                                        chance to transform your life.

                                                    </p>

                                                    <div class="steps">
                                                        <button class="btn-step" data-bs-toggle="modal"
                                                            data-bs-target="#staticBackdrop">Unlock your potential now!
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-xl-6 col-lg-6 col-md-12">
                                                <div class="work-type">

                                                    <div class="work-type-img">
                                                        <img src="assets/image/lap-hand.png" alt="laptop"
                                                            class="lap-img img-fluid">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- type 3 -->
                                <div class="col-xl-12 col-lg-12 col-md-12 mt-5">
                                    <div class="work-types">
                                        <div class="row justify-content-center align-items-center reserve">
                                            <div class="col-xl-6 col-lg-6 col-md-12">
                                                <div class="work-type">
                                                    <div class="work-type-img">
                                                        <img src="assets/image/book1.png" alt="book"
                                                            class="book-img img-fluid">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-xl-6 col-lg-6 col-md-12">
                                                <div class="work-type-txt">
                                                    <div class="type-no">
                                                        <h5>03</h5>
                                                    </div>

                                                    <h3 class="work-type-txt-title">Transform Your Life</h3>
                                                    <p class="work-type-txt-subtitle">Use the insights from the book and
                                                        your consultation to elevate your network marketing business to
                                                        new heights.


                                                    </p>

                                                    <div class="steps">
                                                        <button class="btn-step" data-bs-toggle="modal"
                                                            data-bs-target="#staticBackdrop">Transform your life today!
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <section>
            <div class="section-about">
                <div class="container">
                    <div class="about-container">
                        <div class="row g-3">
                            <div class="col-xl-6 col-lg-6 col-md-12">
                                <div class="about-img">

                                    <img src="assets/banner/Book+Jeff.png" class="img-fluid" alt="">
                                </div>
                            </div>

                            <div class="col-xl-6 col-lg-6 col-md-12">
                                <div class="about-content-txt">
                                    <div class="about-txt">
                                        <h3 class="about-title-txt">Book Your Zoom Call with Jeff</h3>
                                        <p class="about-subtitle-txt">Ready to take the next step? After downloading
                                            your
                                            free <br>e-book, you'll be
                                            given the opportunity to book a <br> personal Zoom
                                            call with Jeff.</p>
                                    </div>
                                </div>

                                <div class="about-count">
                                    <div class="about-count-txt">
                                        <p class="count-subtitle">Now is the time to join</p>
                                        <h3 class="count-title-txt">40,000+</h3>
                                        <p class="count-subtitle">others in transforming your life</p>
                                    </div>

                                    <div class="success-call text-center">
                                        <button class="btn-success" data-bs-toggle="modal"
                                            data-bs-target="#staticBackdrop">Success starts with just one call!</button>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section id="joinUs">
            <div class="section-contact">
                <div class="row gx-5 gy-3">
                    <div class="col-xl-6 col-lg-6 col-md-12">
                        <div class="contact-content">
                            <div class="contact-head">
                                <p class="contact-title">
                                    Download free E-Book and start your transformation!
                                </p>
                            </div>

                            <div class="contact-inputs">
                                <form action="thankyou.php" method="POST" class="needs-validation" novalidate>
                                    <div class="row gx-4 gy-3">
                                        <div class="col-xl-6 col-lg-6 col-md-12">
                                            <div class="contact-input">
                                                <label for="">Full Name</label>
                                                <input type="text" placeholder="Your Name" class="form-control"
                                                    name="fname" id="txtFullName2" required>
                                                <div class="invalid-feedback">
                                                    Please enter valid name
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-xl-6 col-lg-6 col-md-12">
                                            <div class="contact-input">
                                                <label for="">Email Id</label>
                                                <input type="email" placeholder="yourname@example.com" name="email"
                                                    class="form-control" id="txtEmail2" required>
                                                <div class="invalid-feedback">
                                                    Please enter valid email.
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-xl-6 col-lg-6 col-md-12">
                                            <div class="contact-input">
                                                <label class="input-title">Mobile No.</label>
                                                <span class="country-code">+91 | </span>
                                                <input type="text" class="form-control mobile number-only form-control"
                                                    name="mobile" id="txtMobile2" placeholder="Enter your mobile no."
                                                    maxlength="10" required>
                                                <div class="invalid-feedback mobile-validate-2">
                                                    Please enter 10 digit mobile number
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-xl-6 col-lg-6 col-md-12">
                                            <div class="contact-input">
                                                <label for="">State</label>
                                                <select class="form-select state-select" id="txtState2" required
                                                    name="state">
                                                    <option selected hidden value="">Select</option>
                                                </select>
                                                <div class="invalid-feedback">
                                                    Please choose state
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-xl-12 col-lg-12 col-md-12">
                                            <div class="contact-input">
                                                <label for="">Message</label>
                                                <textarea class="form-control" name="message" id="txtMessage2" required
                                                    placeholder="Type message..." rows="3"></textarea>
                                                <div class="invalid-feedback">
                                                    Please enter valid message
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-xl-12 col-lg-12 col-md-12">
                                            <button class="btn-contact" id="btnContact" type="submit">Unlock your
                                                potential
                                                now!</button>
                                        </div>

                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-6 col-lg-6 col-md-12">
                        <div class="contact-img">
                            <img src="assets/image/contact.jpg" class="img-fluid" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </section>


    </main>

    <footer>
        <div class="footer-container">
            <p class="text-center">© Copyright <span id="year">2024</span> | All Right Reserved.</p>
        </div>
    </footer>

    <!-- bootstrap js cdn -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
        integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js"
        integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy"
        crossorigin="anonymous"></script>

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <!-- Bootstrap Datepicker JS -->
    <script
        src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>

    <script src="js/cookie.js"></script>
    <script src="js/url-tracking.js"></script>
    <script src="js/custom-validate.js"></script>
    <script src="js/index.js"></script>

    <script>

        Delete_Cookie('formfilled');

        // Custom function to format date as dd/mm/yyyy
        function formatDate(date) {
            var day = String(date.getDate()).padStart(2, '0');
            var month = String(date.getMonth() + 1).padStart(2, '0'); // Months are zero based
            var year = date.getFullYear();
            return day + '/' + month + '/' + year;
        }

        // Get the current date
        var currentDate = new Date();
        var formattedDate = formatDate(currentDate);

        // Set the current date in the input field
        $("#selectDate").val(formattedDate);

        $(document).ready(function () {
            $('#datepicker').datepicker({
                format: 'dd/mm/yyyy',
                todayHighlight: true,
                autoclose: false,
                startDate: new Date(),
                onSelect: function (dateText) {
                    // Set the selected date into the input field
                    $("#selectDate").val(dateText);
                }
            }).datepicker('show');
        });

        $('#datepicker').on('changeDate', function () {
            $('#selectDate').val(
                $('#datepicker').datepicker('getFormattedDate')
            );
        });


    </script>


    <script>
        $(document).ready(function () {
            $(".offcanvas-body .navItems").click(function () {
                $('.offcanvas-end').offcanvas('hide');
            });
        })
    </script>


</body>

</html>