document.addEventListener("DOMContentLoaded", function () {
  // loader js
  setTimeout(function () {
    document.querySelector(".loader-wrapper").style.display = "none";
    document.body.classList.remove("loading");
  }, 1000);

  let navLinks = this.documentElement.querySelectorAll(".link-items .navItem");
  navLinks.forEach((link) => {
    link.addEventListener("click", function (e) {
      navLinks.forEach((otherLink) => {
        otherLink.classList.remove("active");
      });

      let selectedNav = e.target;
      selectedNav.classList.add("active");
    });
  });

  let toggleUp = document.querySelector(".toggle-up-content");
  if (toggleUp) {
    toggleUp.addEventListener("click", function () {
      window.scrollTo({
        top: 0,
        behavior: "smooth",
      });
    });
  }
});

// toggle up js
window.addEventListener("scroll", function () {
  let toggleUp = document.querySelector(".toggle-up-content");
  if (document.documentElement.scrollTop > 100) {
    toggleUp.style.display = "block";
  } else {
    toggleUp.style.display = "none";
  }
});

const states = [
  { name: "Andhra Pradesh", value: "andhra_pradesh" },
  { name: "Arunachal Pradesh", value: "arunachal_pradesh" },
  { name: "Assam", value: "assam" },
  { name: "Bihar", value: "bihar" },
  { name: "Chhattisgarh", value: "chhattisgarh" },
  { name: "Goa", value: "goa" },
  { name: "Gujarat", value: "gujarat" },
  { name: "Haryana", value: "haryana" },
  { name: "Himachal Pradesh", value: "himachal_pradesh" },
  { name: "Jharkhand", value: "jharkhand" },
  { name: "Karnataka", value: "karnataka" },
  { name: "Kerala", value: "kerala" },
  { name: "Madhya Pradesh", value: "madhya_pradesh" },
  { name: "Maharashtra", value: "maharashtra" },
  { name: "Manipur", value: "manipur" },
  { name: "Meghalaya", value: "meghalaya" },
  { name: "Mizoram", value: "mizoram" },
  { name: "Nagaland", value: "nagaland" },
  { name: "Odisha", value: "odisha" },
  { name: "Punjab", value: "punjab" },
  { name: "Rajasthan", value: "rajasthan" },
  { name: "Sikkim", value: "sikkim" },
  { name: "Tamil Nadu", value: "tamil_nadu" },
  { name: "Telangana", value: "telangana" },
  { name: "Tripura", value: "tripura" },
  { name: "Uttar Pradesh", value: "uttar_pradesh" },
  { name: "Uttarakhand", value: "uttarakhand" },
  { name: "West Bengal", value: "west_bengal" },
  { name: "Andaman and Nicobar Islands", value: "andaman_nicobar_islands" },
  { name: "Chandigarh", value: "chandigarh" },
  {
    name: "Dadra and Nagar Haveli and Daman and Diu",
    value: "dadra_nagar_haveli_daman_diu",
  },
  { name: "Delhi", value: "delhi" },
  { name: "Lakshadweep", value: "lakshadweep" },
  { name: "Puducherry", value: "puducherry" },
];

const selectElements = document.querySelectorAll(".state-select");

selectElements.forEach((select) => {
  states.forEach((state) => {
    const option = document.createElement("option");
    option.value = state.value;
    option.textContent = state.name;
    select.appendChild(option);
  });
});
