// Example starter JavaScript for disabling form submissions if there are invalid fields
(() => {
  "use strict";

  // Fetch all the forms we want to apply custom Bootstrap validation styles to
  const forms = document.querySelectorAll(".needs-validation");

  // Loop over them and prevent submission
  Array.from(forms).forEach((form) => {
    form.addEventListener(
      "submit",
      (event) => {
        if (!form.checkValidity()) {
          event.preventDefault();
          event.stopPropagation();
        }

        form.classList.add("was-validated");
      },
      false
    );
  });
})();

// Get the input element
let numericInput = document.getElementsByClassName("number-only");

for (i = 0; i < numericInput.length; i++) {
  numericInput[i].addEventListener("input", function () {
    this.value = this.value.replace(/\D/g, "");
  });
}

let numberRegex = /^\d{10}$/;

let btnEbook = document.getElementById("btnEbook");
let btnContact = document.getElementById("btnContact");
let btnModal = document.getElementById("btnModalSubmit");

if (btnEbook) {
  btnEbook.addEventListener("click", function () {
    //debugger;
    let userName = document.getElementById("txtFullName").value;
    let userEmail = document.getElementById("txtEmail").value;
    let userMobile = document.getElementById("txtMobile").value;
    let userMessage = document.getElementById("txtMessage").value;
    let state = document.getElementById("txtState").value;

    if (!numberRegex.test(userMobile)) {
      document.querySelector(".mobile-validate").style.display = "block";
      return false;
    } else {
      document.querySelector(".mobile-validate").style.display = "none";
    }

    if (
      userName !== "" &&
      userEmail !== "" &&
      userMobile !== "" &&
      numberRegex.test(userMobile) &&
      userMessage !== "" &&
      state !== ""
    ) {
      //$("#staticBackdrop").modal("show");
    }
  });
}

// Function to validate mobile number
document.addEventListener("DOMContentLoaded", function () {
  const mobileInput = document.getElementById("txtMobile");
  const errorMessage = document.querySelector(".mobile-validate");

  // Function to validate mobile number
  function validateMobile() {
    const mobileValue = mobileInput.value.trim(); // Trim whitespace from the input

    // Regular expression to match exactly 10 digits
    const numberRegex = /^\d{10}$/;

    // Check if the input matches the regex pattern
    if (numberRegex.test(mobileValue)) {
      errorMessage.style.display = "none"; // Hide the error message
    } else {
      errorMessage.style.display = "block"; // Show the error message
    }
  }

  // Add event listeners
  mobileInput.addEventListener("input", validateMobile); // Listen for input changes
  mobileInput.addEventListener("change", validateMobile); // Listen for when focus leaves the input
});

if (btnContact) {
  {
    btnContact.addEventListener("click", function () {
      //debugger;
      let userName2 = document.getElementById("txtFullName2").value;
      let userEmail2 = document.getElementById("txtEmail2").value;
      let userMobile2 = document.getElementById("txtMobile2").value;
      let userMessage2 = document.getElementById("txtMessage2").value;
      let state2 = document.getElementById("txtState2").value;

      if (!numberRegex.test(userMobile2)) {
        document.querySelector(".mobile-validate-2").style.display = "block";
        return false;
      } else {
        document.querySelector(".mobile-validate-2").style.display = "none";
      }

      if (
        userName2 !== "" &&
        userEmail2 !== "" &&
        userMobile2 !== "" &&
        numberRegex.test(userMobile2) &&
        userMessage2 !== "" &&
        state2 !== ""
      ) {
        //$("#staticBackdrop").modal("show");
      }
    });
  }
}

document.addEventListener("DOMContentLoaded", function () {
  const mobileInput2 = document.getElementById("txtMobile2");
  const errorMessage2 = document.querySelector(".mobile-validate-2");

  // Function to validate mobile number
  function validateMobile2() {
    const mobileValue = mobileInput2.value.trim(); // Trim whitespace from the input

    // Regular expression to match exactly 10 digits
    const numberRegex = /^\d{10}$/;

    // Check if the input matches the regex pattern
    if (numberRegex.test(mobileValue)) {
      errorMessage2.style.display = "none"; // Hide the error message
    } else {
      errorMessage2.style.display = "block"; // Show the error message
    }
  }

  // Add event listeners
  mobileInput2.addEventListener("input", validateMobile2); // Listen for input changes
  mobileInput2.addEventListener("change", validateMobile2); // Listen for when focus leaves the input
});

if (btnModal) {
  btnModal.addEventListener("click", function () {
    //debugger;
    let userName3 = document.getElementById("txtFullName3").value;
    let userEmail3 = document.getElementById("txtEmail3").value;
    let userMobile3 = document.getElementById("txtMobile3").value;
    let userMessage3 = document.getElementById("txtMessage3").value;
    let state3 = document.getElementById("txtState3").value;

    if (!numberRegex.test(userMobile)) {
      document.querySelector(".mobile-validate-3").style.display = "block";
      return false;
    } else {
      document.querySelector(".mobile-validate-3").style.display = "none";
    }

    if (
      userName3 !== "" &&
      userEmail3 !== "" &&
      userMobile3 !== "" &&
      numberRegex.test(userMobile3) &&
      userMessage3 !== "" &&
      state3 !== ""
    ) {
      //$("#staticBackdrop").modal("show");
    }
  });
}

// Function to validate mobile number
document.addEventListener("DOMContentLoaded", function () {
  const mobileInput3 = document.getElementById("txtMobile3");
  const errorMessage = document.querySelector(".mobile-validate-3");

  // Function to validate mobile number
  function validateMobile3() {
    const mobileValue = mobileInput3.value.trim(); // Trim whitespace from the input

    // Regular expression to match exactly 10 digits
    const numberRegex = /^\d{10}$/;

    // Check if the input matches the regex pattern
    if (numberRegex.test(mobileValue)) {
      errorMessage.style.display = "none"; // Hide the error message
    } else {
      errorMessage.style.display = "block"; // Show the error message
    }
  }

  // Add event listeners
  mobileInput3.addEventListener("input", validateMobile3); // Listen for input changes
  mobileInput3.addEventListener("change", validateMobile3); // Listen for when focus leaves the input
});
