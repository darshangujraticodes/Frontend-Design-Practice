<?php
// ini_set('display_errors', '1');
// ini_set('display_startup_errors', '1');
// error_reporting(E_ALL);

$request = $_SERVER['REQUEST_METHOD'];
$name = $_REQUEST['fname'];
$mobile = $_REQUEST['mobile'];

$source = $_REQUEST['source'];

    if ($request !== 'POST') {
        http_response_code(405);
        echo 'Method Not Allowed';
        echo '</br>';
        echo "<a href='/'>Go Back</a>";
        die;
    }

    if ($_REQUEST['mobile'] == '') {
        echo 'Please enter valid mobile number';
        echo '</br>';
        echo "<a href='/'>Go Back</a>";
        die;
    }
    if (ctype_alpha(str_replace(' ', '', $name)) === false) {
        echo 'Please enter valid Name';
        echo '</br>';
        echo "<a href='/'>Go Back</a>";
        die;
    }

    $regex = '/^[A-Za-z][a-z\s]*( [A-Z][a-z]*)?$/';

    if(!preg_match($regex, $name)) {
       echo 'Please enter valid Name';
       echo '</br>';
       echo 'please enter name without uppercase character in between';
        echo '</br>';
        echo "<a href='/'>Go Back</a>";
        die;
    }

    if (empty($name)) {
        die;
    }




session_start();
require_once 'send_leads.php';

$postData = new PostData();

if ((!isset($_COOKIE['formfilled'])) && isset($_REQUEST['mobile'])) {

     if($source == "Download Floor Plan") {
setcookie('floorplan', 'yes');


} 

$postData=$postData->callback();
setcookie('formfilled', 'yes');
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <script>
    (function(w, d, s, l, i) {
        w[l] = w[l] || [];
        w[l].push({
            'gtm.start': new Date().getTime(),
            event: 'gtm.js'
        });
        var f = d.getElementsByTagName(s)[0],
            j = d.createElement(s),
            dl = l != 'dataLayer' ? '&l=' + l : '';
        j.async = true;
        j.src =
            'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
        f.parentNode.insertBefore(j, f);
    })(window, document, 'script', 'dataLayer', 'GTM-PRKB4P8D');
    </script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>4life - Thank You</title>
    <link rel="stylesheet" href="css/thankyou.css">
</head>

<body>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-PRKB4P8D" height="0" width="0"
            style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->
    <section class="cd-position-relative cd-z-index-1 cd-padding-y-2xl">
        <div class="cd-container cd-max-width-adaptive-sm cd-text-center">
            <svg class="cd-icon thank-you__icon cd-margin-bottom-sm" viewBox="0 0 96 96" aria-hidden="true">
                <g fill="currentColor">
                    <circle cx="48" cy="48" r="48" opacity=".1"></circle>
                    <circle cx="48" cy="48" r="31" opacity=".2"></circle>
                    <circle cx="48" cy="48" r="15" opacity=".3"></circle>
                    <path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                        stroke-width="2" d="M40 48.5l5 5 11-11"></path>
                    <path transform="rotate(25.474 70.507 8.373)" opacity=".5" d="M68.926 4.12h3.159v8.506h-3.159z">
                    </path>
                    <path transform="rotate(-52.869 17.081 41.485)" opacity=".5"
                        d="M16.097 36.336h1.969v10.298h-1.969z"></path>
                    <path transform="rotate(82.271 75.128 61.041)" opacity=".5" d="M74.144 57.268h1.969v7.547h-1.969z">
                    </path>
                    <circle cx="86.321" cy="41.45" r="2.946" opacity=".5"></circle>
                    <circle cx="26.171" cy="78.611" r="1.473" opacity=".5"></circle>
                    <circle cx="49.473" cy="9.847" r="1.473" opacity=".5"></circle>
                    <circle cx="10.283" cy="63" r="2.946" opacity=".2"></circle>
                    <path opacity=".4" d="M59.948 88.142l10.558-3.603-4.888-4.455-5.67 8.058z"></path>
                    <path opacity=".3" d="M18.512 19.236l5.667 1.456.519-8.738-6.186 7.282z"></path>
                </g>
            </svg>

            <div>
                <h1 class="cd-margin-bottom-xs">Thank you!</h1>
                <p class="thank-you__paragraph cd-margin-bottom-xs">Lorem ipsum dolor sit amet consectetur adipisicing
                    elit</p>

                <p><a class="cd-link" href="index.php">Back to home →</a></p>
            </div>
        </div>
    </section>
</body>

</html>