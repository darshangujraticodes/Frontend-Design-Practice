<?php

class PostData
{
    public function callback()
    {

        $channel = $_COOKIE['cstm_ppc_channel'];
        $campaign = $_COOKIE['cstm_ppc_campaign'];
        $placement = $_COOKIE['cstm_ppc_placement'];
        $keyword = $_COOKIE['cstm_ppc_keyword'];
        $device = $_COOKIE['cstm_ppc_device'];
        $gclid = $_COOKIE['gclid'];

        $ip = $_SERVER['REMOTE_ADDR'];

        $fname = $_REQUEST['fname'];
        $lname = $_REQUEST['lname'];
        $email = $_REQUEST['email'];
        $mobile = str_replace(' ', '', $_REQUEST['mobile']);
        //$projectname = $_REQUEST['projectname'];
        $source = $_REQUEST['source'];
        $state = $_REQUEST['state'];
        $message = $_REQUEST['message'];
        $cc = $_REQUEST['cc'];
        $name = $fname . ' ' . $lname;


        $fullmobile = $cc . ' ' . $mobile;



        // Google Sheet Interation------------------

        $postFields = "entry.335149761=" . $name;
        $postFields .= "&entry.2091968279=" . $email;
        $postFields .= "&entry.1704732802=" . $fullmobile;
        $postFields .= "&entry.1731014865=" . $message;
        $postFields .= "&entry.1039593561=" . $state;
        $postFields .= "&entry.1799428276=" . urlencode($_COOKIE['utm_source']);


        $postFields .= '&entry.2133211774=' . urlencode($_COOKIE['utm_campaign']);
        $postFields .= '&entry.939490048=' . urlencode($_COOKIE['cstm_ppc_channel']);
        $postFields .= '&entry.1154942301=' . urlencode($_COOKIE['utm_keyword']);
        $postFields .= '&entry.1234142523=' . urlencode($_COOKIE['utm_placement']);
        $postFields .= '&entry.1185431252=' . urlencode($_COOKIE['utm_device']);

        $postFields .= '&entry.1780701743=' . urlencode($_COOKIE['utm_medium']);
        $postFields .= '&entry.1966964226=' . urlencode($_COOKIE['gclid']);
        $postFields .= '&entry.2132069230=' . $ip;

        $ch3 = curl_init();
        curl_setopt($ch3, CURLOPT_URL, "https://docs.google.com/forms/u/0/d/e/1FAIpQLSfHRQdEQ9OseLg_MfqEAU9pt7axqiiSZ4xcnDIvgRKdZwr_Ew/formResponse");
        curl_setopt($ch3, CURLOPT_POST, 1);
        curl_setopt($ch3, CURLOPT_POSTFIELDS, $postFields);
        curl_setopt($ch3, CURLOPT_HEADER, 0);
        curl_setopt($ch3, CURLOPT_RETURNTRANSFER, true);
        $result3 = curl_exec($ch3);


        // echo $data_resp;
        // die;


        // do not delete
        return true;
    }
}